<?php
/*
Plugin Name: mmyHelp
Plugin URI: http://wordpresswiki.mkswork.de/
Description: Kontextsensitive Hilfe f&uuml;r WordPress-Adminbereich. Verbindet sich beim Aufruf mit dem WordPress-Wiki.
Author: Markus Kau&szlig;en
Version: 2.0
Author URI: http://www.mkswork.de/
*/

function mmyhelp_head() {

echo"
<style type=\"text/css\">
#chelp	{

position: absolute;
top: 0px;
margin-right: 250px;
padding: 0;
right: 1.5em;
	width: 100px;
	text-align: center;*/
}

</style>
";//echo head
}

function mmyhelp() {


$blogurl = get_bloginfo(url);
$var=$_SERVER['REQUEST_URI'];
$var=ereg_replace("/wp-admin/","",$var);
$var=ereg_replace(".php","",$var);
$var=ereg_replace("\?","_",$var);
$var=ereg_replace("\=","_",$var);

	echo "<div id=\"chelp\">
		<a target=\"popup\" onClick=\"window.open ('', 'popup', 'width=750,height=600,scrollbars=yes, toolbar=no,status=no, resizable=yes,menubar=no,location=no,directories=no,top=5,left=5') \"href=\"http://wordpresswiki.mkswork.de/doku.php/$var\"><img src=\"$blogurl/wp-content/plugins/mmyHelp/mmyhelp.png\" alt=\"Hilfe zu dieser Seite &ouml;ffnen\" title=\"".$var."\"/></a></div>";
}


add_action('admin_head', 'mmyhelp_head');
add_action('admin_footer', 'mmyhelp');
?>
